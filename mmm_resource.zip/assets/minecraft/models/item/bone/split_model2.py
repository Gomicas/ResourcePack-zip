import json
from pathlib import Path
from copy import copy,deepcopy

name = 'brachiosaurus'
split = 4

p = Path(fr'C:\Users\shiyu\OneDrive\default\resourcepacks\博物館\assets\minecraft\models\item\bone\\{name}.json')

class Domain:
  @staticmethod
  def genInvalidDomain():
    return Domain(0,0,False)

  def __init__(self,start,end,valid = True):
    self.start = start
    self.end   = end
    self.valid = valid
  
  def __repr__(self):
    return f'{self.start}->{self.end}'
  
  def min(self):
    return min(self.start,self.end)
  
  def max(self):
    return max(self.start,self.end)

  def intersect(self,domain):
    if domain.max() < self.min() or self.max() < domain.min():
      return Domain.genInvalidDomain()
    start = self.clamp(domain.start)
    end   = self.clamp(domain.end)
    return Domain(start,end)

  def __bool__(self):
    return self.valid

  def clamp(self,i):
    return min(max(i,self.min()),self.max())

  def getparam(self,i):
    # ドメインパラメータ
    if type(i) is Domain:
      # 長さ0の場合は無効なドメインを返す
      if not self.hasLength():
        return Domain.genInvalidDomain()
      return Domain(self.getparam(i.start),self.getparam(i.end))
    # 数値パラメータ
    return (i - self.start)/(self.end - self.start)
  
  def applyParam(self,param):
    if type(param) is Domain:
      return Domain(self.applyParam(param.start),self.applyParam(param.end))
    return self.start + param * (self.end - self.start)

  def invert(self):
    self.start,self.end = self.end,self.start
  
  def hasLength(self):
    return self.start != self.end

  def getZeroDomain(self,get_start:bool): # 長さが0のドメインの取得
    pt = self.start if get_start else self.end 
    return Domain(pt,pt)

class Domain3d:
  def __init__(self,d1:Domain,d2:Domain,d3:Domain):
    self.domains = (d1,d2,d3)

  def __repr__(self):
    return str(self.domains)
  
  def __bool__(self):
    return all(map(bool,self.domains))

  # すべての寸法が有効かどうか(大きさが0でも有効)
  def isValid(self):
    return all(map(bool,self.domains))

  # 0でない寸法の数
  def getDimension(self):
    return sum(map(Domain.hasLength,self.domains))

  # 立体かどうか  
  def isBox(self):
    return self.getDimension() == 3

  # 平面かどうか
  def isPlane(self):
    return self.getDimension() == 2

  def genSurface(self,axis:int,normal:bool):
    return Domain3d(*(self.domains[i].getZeroDomain(not normal) if i == axis else self.domains[i] for i, dom in enumerate(self.domains)))

  def intersect(self,domain3d):
    intersected = tuple(map(lambda x,y:x.intersect(y),self.domains,domain3d.domains))
    return Domain3d(*intersected)
  
  def applyParam(self,domain3d):
    applied = tuple(map(lambda x,y:x.applyParam(y),self.domains,domain3d.domains))
    return Domain3d(*applied)

  def getparam(self,i):
    return tuple(map(Domain.getparam,self.domains,i))

class InvalidFace:
  def intersect(self,domain3d:Domain3d):
    return self

class Face:
  def __init__(self,domain3d:Domain3d,uvw:Domain3d,uvmap):
    self.domain3d = domain3d
    self.uvw      = uvw
    self.uvmap    = uvmap # [0,1] {u:x,v:y} 
  
  def __repr__(self):
    return f'UVW:{self.uvw}'

  def intersect(self,domain3d:Domain3d):
    intersect = self.domain3d.intersect(domain3d)
    # 貫入しなかった場合
    if not intersect.isValid():
      return InvalidFace
    # 平面にならなかった場合
    if intersect.getDimension() < 2:
      return InvalidFace
    params = self.domain3d.getparam(*intersect.domains)
    uvw = self.uvw.applyParam(params)
    return Face(intersect,uvw,self.uvmap)

  def rotate(self):
    # uv入れ替え
    self.uvmap = reversed(self.uvmap)
    # vを反転
    self.uvw.domains[self.uvmap[1]].invert()

class Box:
  def __init__(self,domain3d,faces:dict[str,Face]):
    self.domain3d = domain3d
    self.faces = faces

  def __repr__(self):
    return f'Box{self.domain3d}'
  
  def __bool__(self):
    return bool(self.domain3d)

  def intersect(self,domain3d):
    d3d = self.domain3d.intersect(domain3d)
    if d3d:
      return Box(d3d,map(Face.intersect,self.faces))
    return None



def genFace(dom,json,u,u_normal,v,v_normal):
  uvw_doms = [Domain.genInvalidDomain(),Domain.genInvalidDomain(),Domain.genInvalidDomain()]
  uvw_doms[u] = Domain(json['uv'][0],json['uv'][2])
  if not u_normal: uvw_doms[u].invert()
  uvw_doms[v] = Domain(json['uv'][1],json['uv'][3])
  if not v_normal: uvw_doms[v].invert()
  uvw = Domain3d(*uvw_doms)
  return Face(dom,uvw,[u,v])

def genBox(json):
  dom = Domain3d(*map(Domain,json['from'],json['to']))
  faces = {
    'north': genFace(dom.genSurface(2,False),json['faces']['north'],0,False,1,False) if 'north' in json['faces'] else InvalidFace(),
    'south': genFace(dom.genSurface(2,True ),json['faces']['south'],0,True ,1,False) if 'south' in json['faces'] else InvalidFace(),
    'east' : genFace(dom.genSurface(0,True ),json['faces']['east'] ,2,False,1,False) if 'east'  in json['faces'] else InvalidFace(),
    'west' : genFace(dom.genSurface(0,False),json['faces']['west'] ,2,True ,1,False) if 'west'  in json['faces'] else InvalidFace(),
    'up'   : genFace(dom.genSurface(1,True ),json['faces']['up']   ,0,True ,2,True ) if 'up'    in json['faces'] else InvalidFace(),
    'down' : genFace(dom.genSurface(1,False),json['faces']['down'] ,0,True ,2,False) if 'down'  in json['faces'] else InvalidFace()
  }
  return Box(dom,faces)

box = {
			"from" : [0 , 0 , 0 ],
			"to"   : [16, 13, 10],
			"color": 7,
			"faces": {
				"north": {"uv": [11, 11, 16, 16], "texture": "#missing"},
				"east" : {"uv": [0 , 0 , 16, 16], "texture": "#missing"},
				"south": {"uv": [0 , 0 , 16, 16], "texture": "#missing"},
				"west" : {"uv": [0 , 0 , 16, 16], "texture": "#missing"},
				"up"   : {"uv": [0 , 0 , 16, 16], "texture": "#missing"},
				"down" : {"uv": [0 , 0 , 16, 16], "texture": "#missing"}
			}
		}

print(genBox(box).faces)

# d1 = Domain3d(Domain(0,5),Domain(0,5),Domain(0,5))
# d2 = Domain3d(Domain(0.2,0.5),Domain(0,0.5),Domain(0,0.5))
# b1 = Box(d1)

# print(d1)
# print(d1.genSurface(0,True))
# print(d1.genSurface(0,False))
# print(d1.genSurface(1,True))
# print(d1.genSurface(1,False))
# # print(d2)
# # intersect = b1.intersect(d2)
# # print(intersect)
# # print(bool(intersect))

# print(d1.applyParam(d2))
