import json
from pathlib import Path
import numpy as np

# numpy.matrix は2021/05/22現在非推奨
mrx = np.matrixlib.matrix

class Box