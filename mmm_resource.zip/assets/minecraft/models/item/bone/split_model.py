import json
from pathlib import Path
from copy import copy,deepcopy

name = 'brachiosaurus'
split = 4

p = Path(fr'C:\Users\shiyu\OneDrive\default\resourcepacks\博物館\assets\minecraft\models\item\bone\\{name}.json')

class DomainOutOfRange(Exception):
  pass

class Domain:
  def __init__(self,start,end):
    self.start = start
    self.end   = end

  def __repr__(self):
    return f'[{self.start}..{self.end}]'

  def split(self,split):
    if self.start <= split <= self.end or self.start >= split >= self.end:
      return Domain(self.start,split),Domain(split,self.end)
    raise DomainOutOfRange
  
  def split_with_param(self,split):
    split = self.start + split*(self.end-self.start)
    return self.split(split)

  def abs2param(self,absolute):
    return (absolute - self.start) / (self.end - self.start)

  def reversed(self):
    return Domain(self.end,self.start)

class UV:
  def __init__(self,dom:Domain,axis:int):
    self.axis = axis
    self.dom = dom
  
  def __repr__(self):
    return f'({"xyz"[self.axis]}{self.dom})'

  def split(self,param):
    doms = self.dom.split_with_param(param)
    return map(UV,doms,(self.axis,self.axis))

  def reversed(self):
    return UV(self.dom.reversed(),self.axis)

class Face:
  def __init__(self,positive,u:UV,v:UV,texture,depth):
    self.positive = positive # 面の法線が軸と同方向かどうか
    self.depth = depth       # 軸に対する面の位置
    self.u = u
    self.v = v
    self.texture = texture

  def __repr__(self):
    return f'(u: {self.u},v: {self.v})'

  def split(self,axis,param,depth):
    if self.u.axis == axis:
      return tuple( Face(self.positive,u,self.v,self.texture,self.depth) for u in self.u.split(param))
    if self.v.axis == axis:
      return tuple( Face(self.positive,self.u,v,self.texture,self.depth) for v in self.v.split(param))
    if depth <= self.depth:
      return (None,self)
    return (self,None)

  def rotate(self):
    u,v = self.v, self.u.reversed()
    self.u = u
    self.v = v

class Box:
  def __init__(self,domains:list[Domain,Domain,Domain],rotation,faces:list[list[Face]]):
    self.domains = domains
    self.rotation = rotation
    self.faces = faces

  def __repr__(self):
    return f'{tuple(map(lambda x:x.start,self.domains))} -> {tuple(map(lambda x:x.end,self.domains))}'

  def split(self,axis:int,pos:int):
    if pos <= self.domains[axis].start:
      return None,self
    if self.domains[axis].end <= pos:
      return self,None