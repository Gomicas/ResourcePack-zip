# import numpy as np

# mrx = np.matrixlib.matrix

# A = mrx([[4,0,2],[0,12,4],[0,0,1]])
# B = mrx([[1,0,0],[0,1,0],[0,0,1]])
# C = mrx([[0,-1,16],[1,0,0],[0,0,1]])
# D = mrx([[-1,0,16],[0,-1,16],[0,0,1]])
# E = mrx([[0,1,0],[-1,0,16],[0,0,1]])

# print(B.I*A)
# print(E.I*A)

num = 1500

a = ''.join([f'give @s bone{{CustomModelData:{num},display:{{Name:\'{{"text":"{num}"}}\'}}}}\n' for num in range(1500,1537)])

print(a)