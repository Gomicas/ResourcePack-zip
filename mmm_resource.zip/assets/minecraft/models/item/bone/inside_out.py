import json
from pathlib import Path
import copy

p = Path(r'C:\Users\shiyu\OneDrive\default\resourcepacks\mmm_resource\assets\minecraft\models\item\bone\ankylosaurus.json')


with p.open(encoding='utf-8') as f:
  j = json.loads(f.read())

elements = []

for elem in j['elements']:
  if 'name' in elem and elem['name'] in ('-x','-y','-z'):
    continue
  elements.append(elem)
  print(elem)
  if 'name' in elem: print(elem['name'])
  if 'name' in elem and elem['name'] in 'xyz':
    name = elem['name']
    i = 'xyz'.index(name)
    elem = copy.deepcopy(elem)
    elem['name'] == '-' + name
    elem['from'][i],elem['to'][i] = elem['to'][i],elem['from'][i]
    elements.append(elem)

j['elements'] = elements

with p.open(mode='w') as f:
  f.write(json.dumps(j,indent='  '))
# print(j)
