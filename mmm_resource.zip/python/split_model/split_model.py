from ast import Num
import json as jsonlib
from pathlib import Path
import numpy as np
import math
import copy

from multiprocessing import Pool

# numpy.matrix は2021/05/22現在非推奨
mrx = np.matrixlib.matrix


# 数値を挟みこむ 範囲内かどうか、結果を出力
def clamp(num,mx,mn):
  return mx >= num >= mn , mx if num >= mx else mn if num <= mn else num

# boxの行列を各要素に分解する [(scale,position) * 3]
def deconstructMatrix(matrix):
  return [(matrix[i,i],matrix[i,3]) for i in range(3)]

# 単位boxを指定した位置と大きさに変換する行列 [(scale,position) * 3]
def constructMatrix(x,y,z):
  return mrx([[x[0],0,0,x[1]],[0,y[0],0,y[1]],[0,0,z[0],z[1]],[0,0,0,1]])


class Face:
  @staticmethod
  def box2face(face,matrix):
    x,xpositive,y,ypositive = {
      'north':(0,False,1,False),
      'south':(0,True ,1,False),
      'west' :(2,True ,1,False),
      'east' :(2,False,1,False),
      'up'   :(0,True ,2,True ),
      'down' :(0,True ,2,False)
      }[face]
    scale = [matrix[i,i] for i in range(3)]
    coord = [matrix[i,3] for i in range(3)]
    return mrx([[ (-1 + 2 * xpositive) * scale[x], 0, coord[x] + (not xpositive) * scale[x] ],[0, (-1 + 2 * ypositive) * scale[y],coord[y] + (not ypositive) * scale[y] ],[0,0,1]])

  def __init__(self,face,area,json) -> None:
    face_area = Face.box2face(face,area)
    self.face = face
    self.texture = json['texture']
    uv = json["uv"]

    rot = json["rotation"] if "rotation" in json else 0

    if rot >= 180:
      uv[0],uv[2] = uv[2],uv[0]      
      uv[1],uv[3] = uv[3],uv[1]
    
    uvmatrix = mrx([[uv[2]-uv[0],0,uv[0]],[0,uv[3]-uv[1],uv[1]],[0,0,1]])
    
    if rot%180 == 90:
      uvmatrix = mrx([[0,uv[2]-uv[0],uv[0]],[uv[1]-uv[3],0,uv[3]],[0,0,1]])

    self.matrix = face_area*uvmatrix.I

  def __repr__(self) -> str:
      return str(self.matrix)

  # 現在の面をmatrixで切った時のuvを返す。面に対応するclampsの値がFalseだった場合は空dictを返す。(交差しないため)
  def export(self,matrix,clamps):

    # 面が交差しているかどうか
    axis,direction = {
      'north':(2,0),
      'south':(2,1),
      'west' :(0,0),
      'east' :(0,1),
      'up'   :(1,1),
      'down' :(1,0)
      }[self.face]
    if not clamps[axis][direction]:
      return {}

    trim_area = Face.box2face(self.face,matrix)

    # 行列式が0の場合は面を生成しない
    if np.linalg.det(trim_area) == 0:
      return {}

    area = self.matrix.I*trim_area

    # 90度回転しているかどうか
    if area[0,0] == 0:
      uv = [area[0,2],area[1,2]+area[1,0],area[0,2]+area[0,1],area[1,2]]
      uv = [round(x,5) for x in uv]
      return {self.face:{"uv":uv,"texture":self.texture,"rotation":90}}
    else :
      uv = [area[0,2],area[1,2],area[0,2]+area[0,0],area[1,2]+area[1,1]]
      uv = [round(x,5) for x in uv]
      return {self.face:{"uv":uv,"texture":self.texture}}

class Box:
  class Rotation:
    def __init__(self,json) -> None:
      self.angle = json["angle"]
      self.axis  = json["axis"]
      self.origin = mrx(json["origin"]+[1]).T

    def export(self,matrix):
      origin = (matrix * self.origin).T.tolist()[0][0:3]
      return {"angle":self.angle,"axis":self.axis,"origin":origin}

    def getMatrix(self):
      origin = self.origin
      offset = mrx([[1,0,0,origin[0,0]],[0,1,0,origin[1,0]],[0,0,1,origin[2,0]],[0,0,0,1]])
      axis0, axis1, axis2 = {"x":(0,1,2),"y":(1,2,0),"z":(2,0,1)}[self.axis]
      rotation  = mrx([[0.0,0.0,0.0,0.0],[0.0,0.0,0.0,0.0],[0.0,0.0,0.0,0.0],[0.0,0.0,0.0,1]])
      cos = math.cos(math.radians(self.angle))
      sin = math.sin(math.radians(self.angle))
      rotation[axis1,axis1] = cos
      rotation[axis2,axis2] = cos
      rotation[axis1,axis2] = -sin
      rotation[axis2,axis1] = sin
      rotation[axis0,axis0] = 1
      return offset*rotation*offset.I

  def __init__(self,json) -> None:
    origin = np.array(json['from'])
    size   = np.array(json['to']) - origin
    self.matrix = mrx([[size[0],0,0,origin[0]],[0,size[1],0,origin[1]],[0,0,size[2],origin[2]],[0,0,0,1]])

    # rotationの設定
    self.rotation = Box.Rotation(json["rotation"]) if "rotation" in json and json["rotation"]["angle"] != 0 else None
    # 回転の最適化
    self.optimizeRotation()

    self.faces = [Face(facename,self.matrix,face) for facename,face in json['faces'].items()]

  def optimizeRotation(self):
    if self.rotation:
      # 数値を指定範囲内に収めるときにどれどけすらせばいいかを返す
      def slide(num,mn,mx):
        if num < mn:
          return mn-num
        if mx < num:
          return mx-num
        return 0
      rotated = self.rotation.getMatrix()*self.matrix
      rotated_origin = rotated*mrx([0.5,0.5,0.5,1]).T
      # print((rotated_origin - self.matrix*mrx([0.5,0.5,0.5,1]).T)[0:3])
      # 回転前の位置を最適化
      for i in range(3):
        center = rotated_origin[i,0]
        scale  = self.matrix[i,i]
        offset = center - scale/2
        offset += slide(center + scale/2,-16,32)
        offset += slide(center - scale/2,-16,32)
        self.matrix[i,3] = offset

      A = self.matrix
      B = rotated
      fliped_origin = (B*(A.I*B)**int(abs(180/self.rotation.angle)-1))*mrx([0.5,0.5,0.5,1]).T
      # 回転の中心座標を再設定
      self.rotation.origin = (rotated_origin + fliped_origin) * 0.5

  def __repr__(self) -> str:
      return str(self.matrix)

  # 引数の行列でスケール、サイズ変更を行い、-16~32 の立方体で切り取ったモデルを出力する
  def export(self,matrix,domains:tuple[tuple[Num,Num],tuple[Num,Num],tuple[Num,Num]]):

    # 戻り値となるdict
    result = {}

    # リスケール
    rescaled = matrix * self.matrix

    # 軸ごとに -16 ~ 32 をはみ出しているかどうかをチェックし挟みこむ
    pos_from = []
    pos_to   = []
    axes = []
    clamps = []
    for i,axis in enumerate(deconstructMatrix(rescaled)):
      scale,start = axis
      end = start + scale
      clampstart, start = clamp(start,domains[i][1],domains[i][0])
      clampend, end   = clamp(end,domains[i][1],domains[i][0])
      pos_from.append(start) 
      pos_to.append(end) 
      scale = end - start
      axes.append((scale,start))
      clamps.append((clampstart,clampend))
    clamped_matrix = constructMatrix(*axes)

    result["from"] = pos_from
    result["to"] = pos_to

    # 面ごとにuvを出力
    faces = {}
    for face in self.faces:
      faces |= face.export(matrix.I * clamped_matrix,clamps)
    
    # 面がなかった場合生成しない
    if not faces:
      return []

    result["faces"] = faces
    result["faces"] = faces
    
    # rotation の処理
    if self.rotation:
      result["rotation"] = self.rotation.export(matrix)

    return [result]

def task(ipt):
  self,scale,model_offset,one_model_size,x,y,z = ipt
  conversion_mrx = mrx([[scale,0,0,-x+model_offset],[0,scale,0,-y+model_offset],[0,0,scale,-z+model_offset],[0,0,0,1]])
  clip_domain = (model_offset,model_offset+one_model_size)
  clip_domains = (clip_domain,clip_domain,clip_domain)
  return self.convert(conversion_mrx,clip_domains)

def multiTask(ipts):
    p = Pool(12)
    rslt = p.map(task,ipts)
    return rslt

class Model:
  @staticmethod
  def load(path:Path):
    return Model(jsonlib.loads(path.read_text(encoding='utf8')))

  def __init__(self,json:dict) -> None:
    self.json = json
    self.boxes = list(map(Box,self.json["elements"]))

  def copy(self):
    return copy.copy(self)

  def convert(self,matrix,domains:tuple[tuple[Num,Num],tuple[Num,Num],tuple[Num,Num]]):
    convert_boxes = sum([ box.export(matrix,domains) for box in self.boxes ],[])
    newmodel = self.copy()
    newmodel.boxes = convert_boxes
    return newmodel

  def grid_split(self,scale:int,one_model_size:int) -> list[list[list['Model']]]:
    model_offset = (48 - one_model_size) / 2 - 16
    domain_starts = list(range(scale * -16, scale * 32, one_model_size))

    args = []
    for x in domain_starts:
      for y in domain_starts:
        for z in domain_starts:
          args.append((self,scale,model_offset,one_model_size,x,y,z))
    mapped  = multiTask(args)

    result = []
    i = 0
    for x in domain_starts:
      result.append([])
      for y in domain_starts:
        result[-1].append([])
        for z in domain_starts:
          result[-1][-1].append(mapped[i])
          i+=1
    return result

  def bake(self,path:Path,allow_empty_model:True):
    if allow_empty_model or self.boxes:
      path.write_text(jsonlib.dumps(self.json|{'elements':self.boxes}))
    return allow_empty_model or self.boxes


resource_pack_dir = Path(__file__).parent.parent.parent

# 分割するモデル
name = 'ankylosaurus'
source_model_path = resource_pack_dir/fr'assets\minecraft\models\item\bone\\{name}.json'

# 分割する個数
split = 4

result_dir_path   = source_model_path.with_name('ankylosaurus')

model = Model.load(source_model_path)

if __name__ == "__main__":
  splitted_models = model.grid_split(split,48)

  filenames = [[[f'{k}-{j}-{i}' for i in range(split)] for j in range(split)] for k in range(split)]
  baked = [[[z.bake(result_dir_path/f'{filenames[ix][iy][iz]}.json',allow_empty_model=False) for iz,z in enumerate(y) ] for iy,y in enumerate(x) ] for ix,x in enumerate(splitted_models)]

  cmd = 1500
  txt = ''
  for ix,x in enumerate(filenames):
    for iy,y in enumerate(x):
      for iz,filename in enumerate(y):
        if baked[ix][iy][iz]:
          txt += f'{{"predicate": {{"custom_model_data":{cmd}}}, "model":"item/bone/{name}/{filename}"}},\n'
          cmd += 1

  print(txt)
