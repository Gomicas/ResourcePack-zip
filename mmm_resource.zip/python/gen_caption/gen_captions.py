import os
import base64
from bs4 import BeautifulSoup
from pathlib import Path
import json
import cv2
import numpy as np
import cairosvg
import re

#imwriteが日本語パスに対応していないため再定義
# https://qiita.com/SKYS/items/cbde3775e2143cad7455
def imwrite(filename, img, params=None):
    try:
        ext = os.path.splitext(filename)[1]
        result, n = cv2.imencode(ext, img, params)

        if result:
            with open(filename, mode='w+b') as f:
                n.tofile(f)
            return True
        else:
            return False
    except Exception as e:
        print(e)
        return False

#imreadが日本語パスに対応していないため再定義
def imread(filename, flags=cv2.IMREAD_COLOR, dtype=np.uint8):
    try:
        n = np.fromfile(filename, dtype)
        img = cv2.imdecode(n, flags)
        return img
    except Exception as e:
        print(e)
        return None

path = Path(__file__).absolute().parent

temppath = path/'temp.svg'

fontsize_pattern = re.compile('(?<=font-size:)[\d]+(?:.[\d]+)?(?=px)')
def get_fontsize(style:str):
  return float(fontsize_pattern.search(style).group(0))

def embed(filepath:Path):
  template_path = filepath/'template.svg'
  template = template_path.read_text()

  caption_path = filepath/'captions.json'
  captions = json.loads(caption_path.read_text(encoding='utf8'))

  result_path = filepath/'result'

  args = captions['args'] if 'args' in captions else {}
  colors = captions['colors'] if 'colors' in captions else {}

  def embedsingle(caption:dict,index:str):
    template_html = BeautifulSoup(template,features="lxml")
    template_svg:BeautifulSoup  = template_html.html.body.svg

    for arg in args:
      for text in template_svg.findAll('text'):
        if text.get_text() == arg:
          lines = caption[arg].split('\n')
          font_size = get_fontsize(text['style'])
          line_space = font_size*1.5
          y = float(text['y'][:-2])
          wrapper = text.parent

          # 行ごとに別のtextとして追加
          for line in lines:
            newline = template_html.new_tag('text',**dict(text.attrs))
            newline['y'] = str(y) + 'px'
            newline.string = line
            wrapper.append(newline)
            y += line_space

          text.extract()
          text.string = caption[arg]

    for arg,color in colors.items():
      for rect in template_svg.findAll('rect',{'style':f'fill:rgb({color});'}):
        attrs = { attr:rect[attr] for attr in ('x','y','width','height')}
        b64pict = base64.b64encode((filepath/caption[arg]).read_bytes())
        new = template_html.new_tag('image',**{'xlink:href':'data:image/png;base64,'+str(b64pict)[2:-1]},**attrs)
        rect.replace_with(new)

    stringed = str(template_svg).replace('viewbox','viewBox')
    temppath.write_text(stringed,encoding='utf8')

    cairosvg.svg2png(url=str(temppath),write_to=str(result_path/(str(index)+'.png')),output_width=256)

  for i,caption in captions['captions'].items():
    embedsingle(caption,i)

  bake(filepath,captions['captions'].keys())


resourcepack_path = path.parent.parent/'assets/hakubutukan'

startnum = ord('a')

font_json = lambda captiondir,chars:f'''{{
    "providers": [
        {{
            "type": "bitmap",
            "file": "hakubutukan:font/captions/{captiondir}.png",
            "height": 96,
            "ascent": 33,
            "chars": [
                "{chars}"
            ]
        }}
    ]
}}'''

def bake(captiondir:Path,captionnames:list[str]):
  captiondirname= captiondir.name
  chars = ''
  joined_img = None

  for i,name in enumerate(captionnames):
    imgpath = captiondir/'result'/(name+'.png')

    num = startnum + i
    chars+=chr(num)

    if joined_img is None:
      joined_img = imread(str(imgpath),-1)
    else:
      joined_img = cv2.hconcat((joined_img,imread(str(imgpath),-1)))

  font_json_path = resourcepack_path/'font/captions'/(captiondirname+'.json')
  font_json_path.write_text(font_json(captiondirname,chars))

  font_img_path  = resourcepack_path/'textures/font/captions'/(captiondirname+'.png')
  imwrite(str(font_img_path),joined_img)

  print(f'tellraw @a {{"text":"{chars}","font":"hakubutukan:captions/{captiondirname}"}}')

captiondirs_path = path/'captiondirs.json'
captiondirs = json.loads(captiondirs_path.read_text())

for captiondir in captiondirs:
  embed(path/captiondir)